#include<stdio.h>


int main()
{
printf("Random number is : %d",rand());

return 0;
}
